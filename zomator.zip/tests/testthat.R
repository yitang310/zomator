library(testthat)
library(zomator)

test_check("zomator")
